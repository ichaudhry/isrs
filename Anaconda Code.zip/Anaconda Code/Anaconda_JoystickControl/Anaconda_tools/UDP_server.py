#! /usr/bin/env python

##########################################################################################
# UDP_server.py
#
# contains classes for implementing a simple UDP server for the Anaconda
#
# NOTE: Any plotting is set up for output, not viewing on screen.
#       So, it will likely be ugly on screen. The saved PDFs should look
#       better.
#
# Created: 08/22/14
#   - Joshua Vaughan
#   - joshua.vaughan@louisiana.edu
#   - http://www.ucs.louisiana.edu/~jev9637
#
# Modified:
#   *
#
##########################################################################################

import SocketServer
import logging

logger = logging.getLogger(__name__)

x_data = 0.0
y_data = 0.0

class ThreadedUDPRequestHandler(SocketServer.BaseRequestHandler):
    """
    The RequestHandler class for our server.

    It is instantiated once per connection to the server, and must
    override the handle() method to implement communication to the
    client.
    """

    def handle(self):
        global x_data, y_data, gps_data
        data = self.request[0].strip()
        logging.info('Received UDP data: {}'.format(data))
        
        socket = self.request[1]
        
        x,sep,y = data.partition(',')
        x_data = float(x)
        y_data = float(y)


class ThreadedUDPServer(SocketServer.ThreadingMixIn, SocketServer.UDPServer):
    pass