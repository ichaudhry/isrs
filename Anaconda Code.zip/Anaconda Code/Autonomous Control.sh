#!/usr/bin/env bash

gnome-terminal --window-with-profile=stay_open -e '/home/anaconda/miniconda/bin/python "/home/anaconda/Documents/Anaconda Code/Anaconda_Autonomous"
'