#! /usr/bin/env python

##########################################################################################
# __main__.py
#
# Code to generate and track polygon waypoint arrays, including circles and figure 8s
# Adapted from Anaconda_Waypoint_Array.py
#
# IMU parsing modified from Clearpath Robotics GitHub
#   https://github.com/clearpathrobotics/imu_um6
#
# NOTE: Any plotting is set up for output, not viewing on screen.
#       So, it will likely be ugly on screen. The saved PDFs should look
#       better.
#
# Created: 05/29/14
#   - Joshua Vaughan
#   - joshua.vaughan@louisiana.edu
#   - http://www.ucs.louisiana.edu/~jev9637
#
# Modified:
#   * 05/30/14 - Joshua Vaughan - joshua.vaughan@louisiana.edu
#       - UM6 direct cable port
#       - Course correction is now -180-180 deg, not 0-360 (neg values = turn left)
#   * 06/18/14 - Joshua Vaughan - joshua.vaughan@louisiana.edu
#       - Course correction bug fix
#       - code cleanup
#       - better commenting
#       - added more times to logging
#   * 06/30/14 - Joshua Vaughan - joshua.vaughan@louisiana.edu
#       - Adapted from Anaconda_Waypoint_Array.py
#   * 08/22/14 - Joshua Vaughan - joshua.vaughan@louisiana.edu
#       - moved imports and constants to Anaconda_Settings.py 
#       - renamed to __main__.py as part of refactoring Year 1 Anaconda code
#
##########################################################################################

from Anaconda_Settings import *

if __name__ == '__main__':
    logging.info('Setup Started at ' + datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'))

    ### EXAMPLE USAGE ###
    print '\nStarting up...'

    # Create the PID controller - parameters defines in Anaconda_Settings.py files
    pid = Anaconda_PID.PID(kp, ki, kd, DT, MAX_OUTPUT, MIN_OUTPUT)
    
    # Set initial control output to 0
    control_output = 0.0

    # Set up serial communication with the CANbus adapter
    CAN = Anaconda_CAN.CANbus(CANPort)

    # Create the IMU object and set up data file
    imu = Anaconda_IMUwithGPS.IMU(IMUport)
    imu.setup_data_file()    

    # Create a thread that reads data from the IMU continually
    imu.create_thread()
    time.sleep(1) # Wait for thread to start
    
    #----- Set up control data recording -----
    header = ('Elapsed Time (s)', 
              'IMU Heading (deg from N)',
              'Latitude (+/- = North/South)', 'Longitude (+/- = East/West)',
              'GPS Heading (deg from N)', 'Speed (m/s)',
              'Current Waypoint Number', 
              'Current Waypoint Latitude (+/- = North/South)',
              'Current Waypoint Longitude (+/- = East/West)',
              'Distance to Waypoint (m)', 'Bearing to Waypoint (deg)',
              'Needed Course Correction (deg)',
              'Turn Direction (-1 Left, 0 Straight, 1 Right)',
              'Control Action from PID')
              
    # The filename contains a date/time string of format gpsData_YYYY-MM-DD_HHMMSS.csv    
    data_filename = '/home/anaconda/Documents/Anaconda Code/Data/Control_imuData_withGPS' + datetime.datetime.now().strftime('%Y-%m-%d_%H%M%S')+'.csv'
    
    control_filename = tools.setup_data_file(header, data_filename)
    
    # Define the desired waypoints 
    while True:   
        # wait for real GPS data
        if np.isfinite(imu.data['DATA_GPS'][0]):
            current_location = (imu.data['DATA_GPS'][0], imu.data['DATA_GPS'][1])

            # Decide to use GPS heading calculation or the IMU
            if USE_GPS_HEADING:
                current_heading = imu.data['DATA_GPS'][2]
            else: #using IMU heading            
                current_heading = imu.data['Heading']

            # Define the waypoints based on DRAW_POLYGON, DRAW_CIRCLE, or DRAW_FIGURE8
            if DRAW_POLYGON:
                # Define polygon parameters
                num_sides = 8               # number of sides   
                length_per_side = 100       # length per sides (m)
                direction = 'port'          # which direction to turn at each vertex

                waypoints = geoCalc.get_polygon_waypoints(current_location, current_heading, num_sides, length_per_side, direction = direction)

            elif DRAW_CIRCLE:        
                diameter = 150              # approximate diameter of desired circle
                direction = 'port'     # which direction to turn at each vertex
            
                waypoints = geoCalc.get_circle_waypoints(current_location, current_heading, diameter, direction = direction)
        
            elif DRAW_FIGURE8:        
                diameter = 100              # approximate diameter of desired circle
                direction = 'port'          # which direction to turn at each vertex in first circle
            
                waypoints = geoCalc.get_figure8_waypoints(current_location, current_heading, diameter, direction = direction)
            
            else:
                sys.exit('\n\nPlease select a type of path planning.\n\n')
            
            break
            
        else:
            time.sleep(0.1) # Wait 0.1s to check GPS again
            
    # initialize waypoint counter, increments as we pass through them
    current_waypoint_number = 0
    
    # Define the first waypoint as the first waypoint
    next_waypoint = waypoints[current_waypoint_number]
    
    # Now, begin the control loop
    try:
        print '\nTo begin test, press any key\n'
        raw_input()
        logging.info('Trial Started at ' + datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
        
        while True:
            # Engage the clutch
            clutch  = 3

            # Always full throttle - TODO: change? - 06/05/14
            throttle = 499
        
            # include buckets "forward" - TODO: Why fault at 999? - 06/05/14
            buckets = 900
        
            # Clear the terminal (optional)
            os.system('clear')
            
            imu.show_imu_data()
            
            if imu.data <> {}:
                imu.append_to_data_file()
                current_location = (imu.data['DATA_GPS'][0], imu.data['DATA_GPS'][1])
            
                distance_to_nextWaypoint = geoCalc.calculate_distance(current_location, next_waypoint)
                desired_heading = geoCalc.calculate_bearing(current_location, next_waypoint)

                # Decide to use GPS heading calculation or the IMU
                if USE_GPS_HEADING:
                    current_heading = imu.data['DATA_GPS'][2]
                else: #using IMU heading            
                    current_heading = imu.data['Heading']
                
                # calculate the needed course correction
                course_correction = desired_heading - current_heading
                
                # Correct for heading 'wrap around' to find shortest turn
                if course_correction > 180:
                    course_correction -= 360
                elif course_correction < -180:
                    course_correction += 360
                
                # If the current heading is finite, then calculate the steering input
                if np.isfinite(current_heading):
                    # Just act on the error, so we set the current condition to 0
                    #   and the desired to the course correction
#                     control_output = pid.compute_output(course_correction, 0.0)
                    control_output = pid.compute_output(desired_heading, current_heading)
                else:
                    control_output = 0.0
                
                # record the turn direction - mainly for debugging
                if course_correction > 0:
                    turn_direction = 1  # Turn right
                elif course_correction < 0:
                    turn_direction = -1 # Turn left
                else:
                    turn_direction = 0  # Stay straight
                course_correction_text = ('Port','None','Starboard')
                    
                # convert (-100,100) range of UDP data to to (0,999) range steering angle
                #  499 is center
                steering_angle = int(999./200 * control_output + 99900/200.)
                
                # Send the data over CANbus
                CAN.send_data(throttle, buckets, clutch, steering_angle)
                
                if current_waypoint_number < len(waypoints):
                    print ''
                    print ''
                    print '                          Control Decisions                   '
                    print '======================================================================'
                    print ''          
                    print 'Moving Toward Waypoint {:d} of {:d}'.format((current_waypoint_number+1),len(waypoints))
                    print ''
                    print 'Desired Heading (deg)                                       {:10.4f}'.format(desired_heading)
                    print 'Distance to Next Waypoint (m)                               {:10.4f}'.format(distance_to_nextWaypoint)        
                    print ''      
                    print 'Course Correction (deg)                                     {:10.4f}'.format(course_correction)
                    print '  Turning {}                                                        '.format(course_correction_text[turn_direction+1])
                    print ''
                    print 'PID Controller Output (-100 < Helm Angle < 100)             {:10.4f}'.format(control_output)
                    print ''
                    
                    # If we are within range of the current waypoint move to the next one
                    if distance_to_nextWaypoint < WAYPOINT_TOLERANCE:
                        current_waypoint_number += 1
                        if current_waypoint_number < len(waypoints):
                            next_waypoint = waypoints[current_waypoint_number]
                else:
                    # Send 'stop' data over CANbus - "Neutral Positions"
                    throttle = 0
                    buckets = 499
                    clutch = 0
                    steering_angle = 499
                    CAN.send_data(throttle, buckets, clutch, steering_angle)
                    
                    logging.info('Arrived at Destination at ' + datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
                    
                    print ''
                    print ''
                    print '                          Control Decisions                           '
                    print '======================================================================'
                    print '' 
                    print '                        Arrived at Destination!                       '
                    print '' 
                    print ''                     
                    
                    # break the loop and end script
                    break
            else:
                # Send 'stop' data over CANbus - "Neutral Positions"
                throttle = 0
                buckets = 499
                clutch = 0
                steering_angle = 499
                CAN.send_data(throttle, buckets, clutch, steering_angle)  
                
            data = [imu.data['Time'], 
                    imu.data['Heading'],
                    imu.data['DATA_GPS'][0], imu.data['DATA_GPS'][1],
                    imu.data['DATA_GPS'][2], imu.data['DATA_GPS'][3],
                    current_waypoint_number, next_waypoint[0], next_waypoint[1],
                    distance_to_nextWaypoint, desired_heading, 
                    course_correction, turn_direction, control_output]    
            
            tools.append_to_data_file(control_filename, data)
            
            # 20Hz update (GPS will update at 1Hz)
            time.sleep(0.1)
            
    except (KeyboardInterrupt, SystemExit): # when you press ctrl+c
        imu.stop_thread()
        
        # Send 'stop' data over CANbus - "Neutral Positions"
        throttle = 0
        buckets = 499
        clutch = 0
        steering_angle = 499
        CAN.send_data(throttle, buckets, clutch, steering_angle)
        
        logging.info('Trial Finished at ' + datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
    
    # Executed after successful completion (breaking the while loop)   
    imu.stop_thread()
        
    # Send 'stop' data over CANbus - "Neutral Positions"
    throttle = 0
    buckets = 499
    clutch = 0
    steering_angle = 499
    CAN.send_data(throttle, buckets, clutch, steering_angle)
    
    logging.info('Trial Finished at ' + datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
