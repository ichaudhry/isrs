#! /usr/bin/python

'''#######################################################################################
# Basic polling of a gps unit via gpsd and reporting of data in terminal
#
# Adapted from code written by Dan Mandle - http://dan.mandle.me September 2012
# License: GPL 2.0
#
# Modified:
#   * 2/26/14 - Joshua Vaughan - joshua.vaughan@louisiana.edu
#       - initial adaptation
#   * 4/25/14 - Joshua Vaughan - joshua.vaughan@louisiana.edu
#       - updated to class-based structure
#       - added print and logging functions
#   * 5/11/14 - Joshua Vaughan - joshua.vaughan@louisiana.edu
#       - Fixed some PEP8 problems
#       - Slightly improved commenting
#   * 5/13/14 - Joshua Vaughan - joshua.vaughan@louisiana.edu
#       - Added "if main" to allow running standalone
#       - 
##########################################################################################
'''

import os
from gps import *
import datetime, csv
import dateutil.parser
import threading
import logging

logging.basicConfig(level=logging.DEBUG,
                    format='From %(threadName)-10s: %(message)s',
                    )

# clear the terminal (optional)
os.system('clear') 


class GpsPoller(threading.Thread):
    def __init__(self):
        threading.Thread.__init__(self, name = 'GPS Thread')
        self.session = gps(mode=WATCH_ENABLE)   # Start the stream of GPS info
        self.current_value = None
        self.running = True                     # Set the thread running to true

    def get_current_value(self):
        return self.current_value

    def run(self):
        while self.running:
            # Continue to loop and grab EACH set of gpsd info to clear the buffer
            self.session.next()


class GPS_reader(object):
    # TODO: Should this be on its own thread?

    def __init__(self):
        self.gpsp = GpsPoller()  # create the thread
        self.gpsp.daemon = True
        self.gpsp.start()        # start it up
    
    def parse_gps_data(self):
        # Get the GPS data and store in local variables
        self.mode = self.gpsp.session.fix.mode
        self.UTC_time = self.gpsp.session.utc

        self.gps_time_err = self.gpsp.session.fix.ept

        if self.UTC_time is not None:
            self.UTC_time_parsed = dateutil.parser.parse(self.UTC_time)
            self.UTC_time_string = self.UTC_time_parsed.strftime('%Y-%m-%d - %H:%M:%S')

        if self.mode > 2:
            self.num_sats = len(self.gpsp.session.satellites) 
        else:
            self.num_sats = 0

        self.lat = self.gpsp.session.fix.latitude
        self.long = self.gpsp.session.fix.longitude
        self.alt = self.gpsp.session.fix.altitude

        self.lat_err = self.gpsp.session.fix.epy
        self.long_err = self.gpsp.session.fix.epx
        self.alt_err = self.gpsp.session.fix.epv

        self.speed = self.gpsp.session.fix.speed
        self.heading = self.gpsp.session.fix.track
        self.climb = self.gpsp.session.fix.climb

        self.speed_err = self.gpsp.session.fix.eps
        self.heading_err = self.gpsp.session.fix.epd
        self.climb_err = self.gpsp.session.fix.epc

    def show_gps_data(self):
        
        # Parse the GPS data first
        self.parse_gps_data()
        
        # Then print it to the screen
        print ''
        print 'GPS Data'
        print '============================================================================'
        print ''
        print 'Time (UTC)                                       ' ,self.UTC_time_string 
        print 'Timestamp error estimate (s)                     ' ,self.gps_time_err
        print ''
        print 'Latitude (+/- = North/South)                     ' ,self.lat
        print 'Longitude (+/- = East/West)                      ' ,self.long
        print 'Altitude (m)                                     ' ,self.alt
        print ''
        print 'Latitude Error Estimate (m)                      ' ,self.lat_err
        print 'Longitude Error Estimate (m)                     ' ,self.long_err
        print 'Altitude Error Estimate (m)                      ' ,self.alt_err
        print ''
        print '----------------------------------------------------------------------------'
        print ''
        print 'Speed (m/s)                                      ' ,self.speed
        print 'Heading Over Ground (deg from N)                 ' ,self.heading
        print 'Climb rate (m/s)                                 ' ,self.climb
        print ''
        print 'Speed Error Estimate (m/s)                       ' ,self.speed_err
        print 'Heading Error Estimate (deg)                     ' ,self.heading_err
        print 'Climb Error Estimate (m/s)                       ' ,self.climb_err
        print ''
        print '----------------------------------------------------------------------------'
        print ''
        print 'NMEA mode (0=none, 1=no fix, 2=2D, 3=3D)         ' ,self.mode
        print 'Number of Satellites                             ' ,self.num_sats
        print ''
        print '============================================================================'


    def setup_data_file(self):
        # Set up the csv file to write to. 
        # The filename contains a date/time string of format gpsData_YYYY-MM-DD_HHMMSS.csv
        data_filename = 'gpsData_' + datetime.datetime.now().strftime('%Y-%m-%d_%H%M%S')+'.csv'
        with open(data_filename, "wb") as data_file: 
            writer = csv.writer(data_file)
    
            # Define and write the header row immediately after opening
            header = ('Time (UTC)', 'Latitude (+/- = North/South)','Longitude (+/- = East/West)',
                    'Altitude (m)','Latitutde Error Estimate (m)','Longitude Error Estimate (m)',
                    'Altitude Error Estimate (m)','Speed (m/s)','Heading (deg from N)',
                    'Climb Rate (m/s)','Speed Error Estimate (m/s)','Heading Error Estimate (deg)',
                    'Climb Error Estimate (m/s)','Mode','Number of Satellites')
            writer.writerow(header) 
        
        return writer, data_filename
        
        
    def write_data_file(self,writer,data_filename):
        data = [self.UTC_time, self.lat, self.long, self.alt, self.lat_err, self.long_err, 
                self.alt_err, self.speed, self.heading, self.climb, self.speed_err, 
                self.heading_err, self.climb_err, self.mode, self.num_sats]
            
        with open(data_filename, "ab") as data_file: 
            # TODO: Be smarter about how and when to save data
            writer = csv.writer(data_file)
            writer.writerow(data)
        
    
    def stop_gps(self):
        print "\nStopping GpsPoller Thread..."
        self.gpsp.running = False
        self.gpsp.join(2)             # wait for the thread to finish what it's doing



if __name__ == '__main__':
    gps = GPS_reader() # create the thread
    
    try:
        data_writer, data_filename = gps.setup_data_file()
        
        while True:
            # Clear the terminal (optional)
            os.system('clear')
            
            gps.show_gps_data()
            
            # If the GPS has a fix, save the data
            if gps.mode > 1:
                gps.write_data_file(data_writer, data_filename)
            
            # Time between printing readings
            time.sleep(0.1) 
            
    except (KeyboardInterrupt, SystemExit): #when you press ctrl+c
        gps.stop_gps()

    print "Done.\nExiting."