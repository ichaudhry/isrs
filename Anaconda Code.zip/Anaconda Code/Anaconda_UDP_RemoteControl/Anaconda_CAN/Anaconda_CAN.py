#! /usr/bin/env python

'''#######################################################################################
# Anaconda_CAN.py
#
# Script to pass commands from a UDP-source to an Arduino for issue through CAN bus
#
# Created:5/14/14
#   - Joshua Vaughan
#   - joshua.vaughan@louisiana.edu
#   - http://www.ucs.louisiana.edu/~jev9637
#
# Modified:
#   * 
##########################################################################################
'''

# Standard
import sys, time

import numpy as np
import serial, logging

logger = logging.getLogger(__name__)

class CANbus(object):
    ''' Class for sending/receiving CANbus data'''
    def __init__(self, port):
        self.port = port
        self.ser = serial.Serial(port, 115200)
        self.command_data = np.asarray([499, 499, 499, 0, 0, 0, 0, 0, 0, 1])

    # Sends throttle and steering angle commands to platform
    def send_data(self, throttle, buckets, clutch, steering_angle):

        #     Helm: 0-999 (499 center)
        #     Port Bucket: 0-999 (499 center)
        #     Stbd Bucket: 0-999 (499 center)
        #     Port Throttle: 0-999
        #     Stbd Throttle: 0-999
        #     Clutch - 3 to engage
        #     Port Int
        #     Stbd Int
        #     Idle
        #     Control Request: 1 to request control
        self.command_data = np.asarray([steering_angle, buckets, buckets, throttle, throttle, clutch, 0, 0, 0, 1])

        # Uncomment below to print values being sent
        CAN_string = 'Sending: Throttle = ' + str(throttle) + '\t Buckets = ' + str(buckets) + '\t Helm Angle = ' + str(steering_angle)
        # print 'Sending: Throttle = ' + str(throttle) + '\t Buckets = ' + str(buckets) + '\t Helm Angle = ' + str(steering_angle)
        logging.info(CAN_string)
    
        # Write the data to the serial connection - to the Arudino for CAN bus formatting
        self.ser.write(str(self.command_data))
    
    def __del__(self):
        self.ser.close()
    
    
if __name__ == '__main__':
    ''' Example use of this class'''
    import pygame
    
    # DEFINES
    VEL_SCALE = -0.5
    ROT_SCALE = 1.0


    # MAIN SCRIPT
    # serial port will have to change based on configuration
    CANPort = '/dev/tty.usbserial-A601EGPS'

    CAN = CANbus(CANPort)

    pygame.init()

    print "------------------------------------"
    print "-- Anaconda Joystick Interface  --"
    print "------------------------------------"
    print "Please confirm that the joytstick and"
    print "boat are plugged in and press ENTER"
    raw_input()

    # Joystick connection
    print "\nConnecting to joystick..."
    if pygame.joystick.get_count() < 1:
        print "No joystick found, quitting"
        sys.exit(1)
    else:
        joy = pygame.joystick.Joystick(0)
        joy.init()
    print "Joystick found"


    while True:
        try:
            for event in pygame.event.get():
                if event.type == pygame.QUIT: break
        
            # If the "joystick"-button is pressed, issue commands
            if joy.get_button(0):
                clutch  = 3
            
                y_data = joy.get_axis(1)
            
                x_data = joy.get_axis(0)
            
                # convert (0,100) range of joystick data to (0,999) range throttle
                #   Then scale according to VEL_SCALE to limit
            
                # For now, no negative values of y_data
                if y_data > 0:
                    y_data = 0
            
                throttle = int(VEL_SCALE * (999.) * y_data)
            
                # include buckets "forward" if have nonzero throttle
                if throttle > 10:
                    buckets = int(900)
                else:
                    buckets = int(499)
                        
                # convert (-100,100) range of UDP data to to (0,999) range steering angle
                #  499 is center
                steering_angle = int(999./2 * x_data + 999/2.)
            
                # Send the data
                CAN.send_data(throttle, buckets, clutch, steering_angle)

            else: # if the deadman switch is not pressed
                # Send default configuration data
                CAN.send_data( 0, 499, 0, 499)
            
            time.sleep(0.1)
        
        except KeyboardInterrupt:
            # Catches CTRL-C
            break

    # Program terminated
    print "Program finished, cleaning up..."
    joy.quit()  


    print "Cleanup successful, exiting..."
    time.sleep(1)
    sys.exit()  