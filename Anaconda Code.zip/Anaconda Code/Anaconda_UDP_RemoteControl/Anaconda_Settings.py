#! /usr/bin/env python

##########################################################################################
# Anaconda_Settings.py
#
# Initilization for the autonomous operation of the Anaconda
#   Will likely have to move to configparser as project grows. This works for now.
# 
# Usage:
#   1. Uncomment the settings that you would like to use
#   2. import this file into the script where the settings are needed:
#           from Anaconda_settings import *
#
# NOTE: Any plotting is set up for output, not viewing on screen.
#       So, it will likely be ugly on screen. The saved PDFs should look
#       better.
#
# Created: 06/29/14
#   - Joshua Vaughan
#   - joshua.vaughan@louisiana.edu
#   - http://www.ucs.louisiana.edu/~jev9637
#
# Modified:
#   * 08/22/14 - Joshua Vaughan - joshua.vaughan@louisiana.edu
#       - structure changed while refactoring the Year 1 Anaconda codebase
#
##########################################################################################

import numpy as np

import os, sys

import serial
from select import select
import socket
import SocketServer
import struct

import csv
import datetime
import time

import threading, logging

# Project Specific Imports
from Anaconda_IMUandGPS import Anaconda_IMUwithGPS
from Anaconda_CAN import Anaconda_CAN
from Anaconda_tools import geographic_calculations as geoCalc
from Anaconda_tools import misc_tools as tools
from Anaconda_tools import UDP_server



#---------- Parameters, constants, etc. ------------
VEL_SCALE = 0.5                 # proportion of maximum throttle allowed



# ---------- Network Settings -------------
# Dr. Vaughan's Apartment 
# HOST = '10.0.1.130'
# PORT = 2390

# # UWIN - Dr. Vaughan's Office
# HOST = '10.50.62.81'
# PORT = 2390

# Localhost
# HOST  = '10.42.0.1'
# PORT = 2390

# On the Anaconda
HOST  = '192.168.0.102'
PORT = 2390

# ---------- CANbus Settings ---------------
# CANPort = '/dev/tty.usbserial-A601EGPS'       # Sparkfun Board with MacBook
# CANPort = '/dev/tty.usbmodema01141'           # Blue Arduino Uno with Dr. Vaughan's Macbook
CANPort = '/dev/ttyACM0'                        # Chromebook

# ---------- IMU Settings ------------------
# IMUport = '/dev/tty.USA19H142P1.1'            # Keyspan USB-> Serial 
# IMUport = '/dev/tty.usbserial-FTGSQ1XH'       # UM6 JST -> USB
IMUport = '/dev/ttyUSB0'                        # Chromebook


# ---------- Define the logging level ----------
# Debug level logging
# log_filename = '/home/anaconda/Documents/Anaconda Code/Logs/Anaconda_DebugLog_' + datetime.datetime.now().strftime('%Y-%m-%d_%H%M%S') + '.log'
# logging.basicConfig(filename=log_filename, level=logging.DEBUG,
#                     format='From %(threadName)-10s - %(module)s Module: %(message)s')

## Info level logging
log_filename = '/home/anaconda/Documents/Anaconda Code/Logs/Anaconda_InfoLog_' + datetime.datetime.now().strftime('%Y-%m-%d_%H%M%S') + '.log'
logging.basicConfig(filename = log_filename, level=logging.INFO,
                    format='From %(threadName)-10s - %(module)s Module: %(message)s')

## Critical level logging
# log_filename = '/home/anaconda/Documents/Anaconda Code/Logs/Anaconda_CriticalLog_' + datetime.datetime.now().strftime('%Y-%m-%d_%H%M%S') + '.log'
# logging.basicConfig(filename = log_filename, level=logging.CRITICAL,
#                     format='From %(threadName)-10s - %(module)s Module:: %(message)s')
