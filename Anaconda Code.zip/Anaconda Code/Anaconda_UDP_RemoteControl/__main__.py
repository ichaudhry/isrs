#! /usr/bin/env python

##########################################################################################
# __main__.py
#
# Script to receive commands from a UDP-source to an Arduino for issue through CAN bus
# Also passes basic  basic GPS information back to IP address that's sending commands
#
# Created: 6/1/14
#   - Joshua Vaughan
#   - joshua.vaughan@louisiana.edu
#   - http://www.ucs.louisiana.edu/~jev9637
#
# Modified:
#   * 06/16/14 - Joshua Vaughan - joshua.vaughan@louisiana.edu
#       - changed to UDP broadcast
#       - general code cleanup
#   * 08/22/14 - Joshua Vaughan - joshua.vaughan@louisiana.edu
#       - started conversion to App/package structure and refactoring
#       - moved settings to Anaconda_Settings.py
#   * 09/05/14 - Joshua Vaughan - joshua.vaughan@louisiana.edu
#       - further code cleanup
#       - improve commenting
#
# TODO:
#   * SAFETY checks
#   * error handling
#   * smooth transitions?
#   * bucket commands to allow reverse
##########################################################################################

# Import settings, configuration, and import statements from Anaconda_settings.py
from Anaconda_Settings import *

# ----- Set up serial communication with the CANbus adapter
CAN = Anaconda_CAN.CANbus(CANPort)

# ----- Set up server to receive commands over UDP
server = UDP_server.ThreadedUDPServer((HOST, PORT), UDP_server.ThreadedUDPRequestHandler)
ip, port = server.server_address

# Start a thread with the server -- that thread will then start one
# more thread for each request
server_thread = threading.Thread(target=server.serve_forever)

# Exit the server thread when the main thread terminates
server_thread.daemon = True
server_thread.start()
logging.info('Server loop running in thread: {}'.format(server_thread.name))


# ----- Set up broadcast of the GPS data
GPS_sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
GPS_sock.bind(('', 0))
GPS_sock.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)


# ----- Set up IMU
# Create the IMU object and set up the date file
imu = Anaconda_IMUwithGPS.IMU(IMUport)
imu.setup_data_file()    

# Create a thread that reads data from the IMU continually
imu.create_thread()
time.sleep(0.1)

# Initialize x and y data as 0 and gps_data as an empty string
x_data = 0.0
y_data = 0.0
gps_data = ''

try:
    while True:
        # Get data from UDP server
        x_data = UDP_server.x_data
        y_data = UDP_server.y_data
        
        # Uncomment below to print raw data received over UDP
        # print '\nUDP Data:\t (' + str(x_data) + ', ' + str(y_data) + ')'
        
        logging.info('Received UDP Data:\t ' + str(x_data) + ', ' + str(y_data))

        # Clear the terminal (optional)
        os.system('clear')
        
        imu.show_imu_data()
        
        # Save and broadcast IMU/GPS data if it is connected
        if imu.data <> {}:
            imu.append_to_data_file()
            
            # Broadcast the GPS data over the UDP socket
            gps_data = '{:.4f}, {:.4f}, {:.0f}, {:.2f}'.format(imu.data['DATA_GPS'][0], imu.data['DATA_GPS'][1], imu.data['DATA_GPS'][2], imu.data['DATA_GPS'][3])
            logging.info('Sending: ' + gps_data)
            GPS_sock.sendto(gps_data, ('<broadcast>', 2390))

        if x_data or y_data:
            clutch = 3  
        else:
            clutch = 0

        # For now, no negative values of y_data
        if y_data < 0:
            y_data = 0

        # convert (0,100) range of UDP data to (0,999) range throttle
        #   Then scale according to VEL_SCALE to limit
        throttle = int(VEL_SCALE * (999./100) * y_data)

        # include buckets "forward" if have there is nonzero throttle
        if throttle > 10:
            buckets = int(900)
        else:
            buckets = int(499)

        # convert (-100,100) range of UDP data to to (0,999) range steering angle
        #  499 is center
        steering_angle = int(999./200 * x_data + 99900/200.)

        # Now, actually send the data
        CAN.send_data(throttle, buckets, clutch, steering_angle) 


#             # Get the CANbus data from the Vector Controls Unit
#             CANdata = get_data()
#             
#             # Define the variables for all the Vector Controls Data to receive
#             stbdNozzleFeedback = CANdata[0]
#             stbdBucketFeedback = CANdata[1]
#             portNozzleFeedback = CANdata[2]
#             portBucketFeedback = CANdata[3]
#             stbdIntFeedback = CANdata[4]
#             portIntFeedback = CANdata[5]
#             controlUnit_faults = CANdata[6]
#             control_faults = CANdata[7]
#             nonFU_faults = CANdata[8]
#             feedbackSensor_faults = CANdata[9]
#             localStation_faults = CANdata[10]
#             remoteAllowed = CANdata[11]
#             stationInControl = CANdata[12]
#             clutchPermissives = CANdata[13]


#             # Print CANbus data to the screen
        print ''
        print '                             CANbus Data'
        print '======================================================================'
        print 'Sending:' 
        print '  Throttle                                                  {:10.0f}'.format(throttle)
        print '  Buckets                                                   {:10.0f}'.format(buckets)
        print '  Helm                                                      {:10.0f}'.format(steering_angle)
        print '' 
#             print 'Received:'
#             print '  Starboard Nozzle                                {:10.0f}'.format(stbdNozzleFeedback)
#             print '  Port Nozzle                                     {:10.0f}'.format(portNozzleFeedback)
#             print '' 
#             print '  Starboard Bucket                                {:10.0f}'.format(stbdBucketFeedback)
#             print '  Port Bucket                                     {:10.0f}'.format(portBucketFeedback)
#             print '' 
#             print '  Starboard Interceptor                           {:10.0f}'.format(stbdIntFeedback)
#             print '  Port Interceptor                                {:10.0f}'.format(portIntFeedback)
#             print ''
#             print 'Control Mode:'
#             print '  Remote Control is Allowed                       {:>10}'.format(str(bool(remoteAllowed)))
#             print '  Remote Control is Active                        {:>10}'.format(str(bool(stationInControl)))
#             print ''
#             print 'Faults: '
#             print '  Control Unit Faults                             {:10.0f}'.format(controlUnit_faults)
#             print '  Control Faults                                  {:10.0f}'.format(control_faults)
#             print '  Sensors Faults                                  {:10.0f}'.format(feedbackSensor_faults)
#             print '  Local Station Faults                            {:10.0f}'.format(localStation_faults)
#             print ''
#             print '======================================================================'
#               
        time.sleep(0.1)
    
except (KeyboardInterrupt, SystemExit): # when you press ctrl+c
    pass
    
print "Done.\nExiting."    
